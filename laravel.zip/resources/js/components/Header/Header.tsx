import React, { useState } from 'react';
import { Link, usePage } from '@inertiajs/react';
import Logo from '@/components/ui/Logo/Logo';
import Button from '@/components/ui/Button/Button';
import type { PageProps } from '@/types';

const Header: React.FC = () => {
    const { auth } = usePage<PageProps>().props;
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const navLinks = [
        { label: 'Home', href: '/' },
        { label: 'Features', href: '/#features' },
        { label: 'About', href: '/#about' },
    ];

    return (
        <header className="header">
            <div className="header__container">
                <div className="header__logo">
                    <Logo />
                </div>

                <nav className="header__nav">
                    {navLinks.map((link) => (
                        <Link
                            key={link.href}
                            href={link.href}
                            className="header__nav-link"
                        >
                            {link.label}
                        </Link>
                    ))}
                </nav>

                <div className="header__actions">
                    {auth.user ? (
                        <Link href="/dashboard">
                            <Button variant="primary" size="sm">
                                Dashboard
                            </Button>
                        </Link>
                    ) : (
                        <>
                            <Link href="/login" className="header__nav-link">
                                Sign In
                            </Link>
                            <Button variant="primary" size="sm" as="a" href="/login">
                                Get Started
                            </Button>
                        </>
                    )}

                    <button
                        className="header__mobile-toggle"
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                        aria-label="Toggle menu"
                        aria-expanded={mobileMenuOpen}
                    >
                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                        >
                            {mobileMenuOpen ? (
                                <>
                                    <line x1="18" y1="6" x2="6" y2="18" />
                                    <line x1="6" y1="6" x2="18" y2="18" />
                                </>
                            ) : (
                                <>
                                    <line x1="3" y1="6" x2="21" y2="6" />
                                    <line x1="3" y1="12" x2="21" y2="12" />
                                    <line x1="3" y1="18" x2="21" y2="18" />
                                </>
                            )}
                        </svg>
                    </button>
                </div>
            </div>

            <div
                className={`header__mobile-menu ${
                    mobileMenuOpen ? 'header__mobile-menu--open' : ''
                }`}
            >
                {navLinks.map((link) => (
                    <Link
                        key={link.href}
                        href={link.href}
                        className="header__mobile-link"
                        onClick={() => setMobileMenuOpen(false)}
                    >
                        {link.label}
                    </Link>
                ))}
                {!auth.user && (
                    <Link
                        href="/login"
                        className="header__mobile-link"
                        onClick={() => setMobileMenuOpen(false)}
                    >
                        Sign In
                    </Link>
                )}
            </div>
        </header>
    );
};

export default Header;
